import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-scale-login',
  templateUrl: './small-scale-login.component.html',
  styleUrls: ['./small-scale-login.component.css']
})
export class SmallScaleLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
