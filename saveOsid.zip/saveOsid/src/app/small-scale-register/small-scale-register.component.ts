import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-scale-register',
  templateUrl: './small-scale-register.component.html',
  styleUrls: ['./small-scale-register.component.css']
})
export class SmallScaleRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
